package com.example.adamkhar;

public enum Positions {
    Down,Up,Boat
}