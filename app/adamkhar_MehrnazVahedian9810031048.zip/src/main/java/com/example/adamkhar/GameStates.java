package com.example.adamkhar;

public enum GameStates {
    Continue, Win, GameOver
}
